package com.example.grp2.controller;



import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.example.grp2.model.MemberVO;
import com.example.grp2.service.MemberSrv;

//main.jsp��������
@Controller
public class MainCtr {
	
	@Autowired
	MemberSrv memberSrv;
	
	
	
	//controlleró�� ���鶧�� �ּ� ũ�� �Ű澲�� �ʱ� - �⺻�ּҷ� �����
	//���� ����� ùȭ��
	@RequestMapping("")
	public String getMain() {
		return "main";
	}
	
	
	
	@RequestMapping(value = "/login", method = RequestMethod.GET) 
	public String getLogin() {
		return "login";
	}
	
	/*
	 * @RequestMapping(value = "/login", method = RequestMethod.POST) public
	 * ModelAndView setLogin(@ModelAttribute MemberVO mvo) {
	 * 
	 * //System.out.println(memberSrv.checkLogin(mvo));
	 * //System.out.println(mvo.getMemID()); //System.out.println(mvo.getMemPwd());
	 * 
	 * MemberVO vo = memberSrv.checkLogin(mvo);
	 * 
	 * ModelAndView mav = new ModelAndView(); if(vo != null) { mav.addObject("msg",
	 * "�α��μ���"); mav.setViewName("redirect:/memberList"); }else {
	 * mav.addObject("msg", "��ϵ� ����ڰ� �ƴմϴ�."); mav.setViewName("login"); } return
	 * mav; }
	 */
	
	
	@RequestMapping(value = "/login", method = RequestMethod.POST) 
	@ResponseBody
	public String setLogin(@ModelAttribute MemberVO mvo, HttpSession session) {
		MemberVO vo = memberSrv.checkLogin(mvo, session);
		System.out.println(vo);
		String msg;
		if(vo != null) {
			msg = "success";
		}else {
			msg = "failure";
		}
		return msg;
	}
	
	
	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		memberSrv.logout(session);
		return "main";
	}
	
	
	
	
	@RequestMapping(value = "/register", method = RequestMethod.GET)
	//get������� �ϸ� �ؿ� ȭ���� ���-ȭ�� ���
	public String getRegister() {
		return "register";
	}
	
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	//POST(action)������� �ϸ� 
	public String getRegisterDo(@ModelAttribute MemberVO mvo) {
		//db�� ����
		memberSrv.setMember(mvo);
		return "redirect:/login";
	}
	
	
	
	@RequestMapping("/memberList") //ȸ�����-���
			
	//���� ������ ����� ���ϰ� searchOpt�ϸ� defaultValue	
	public ModelAndView getMemberList(@RequestParam(defaultValue = "mem_name")String searchOpt, 
			//�߸��Է��ϰų� �����̽��� ġ�ų� �Ҷ�
			@RequestParam (defaultValue = "")String words) {
		
		//��������
		int count = memberSrv.getMemberCount(searchOpt, words);
		//
		
		List<MemberVO> list =  memberSrv.getMemberList(searchOpt, words);
		
		ModelAndView mav = new ModelAndView();
		mav.addObject("list", list);
		mav.setViewName("memberList");

		mav.addObject("searchOpt", searchOpt);
		mav.addObject("words", words); //�˻��Ѱ� �����ֵ��� ��
		mav.addObject("count", count);
		
		return mav;
	}
	
	
	//���Ѿ�����Ʈ ajax
	@RequestMapping(value = "/memConfirm", method = RequestMethod.POST)
	@ResponseBody
	public String memConfirm(@ModelAttribute MemberVO mvo) {
		//System.out.println(mvo);
		memberSrv.memConfirm(mvo);
		return "success";
	} //���� xml -dao ������� �ϱ�
	
	
	@RequestMapping(value = "/checkID", method = RequestMethod.POST)
	@ResponseBody
	public String checkID(@RequestParam String memID ) {
		int result =  memberSrv.checkID(memID);
		
		String msg;
		if(result > 0 ) {
			msg = "NO";
		}else {
			msg = "YES";
		}
		return msg;
	}
	

}










