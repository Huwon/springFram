package com.example.grp2.repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.grp2.model.MemberVO;

@Repository
public class MemberDao {
	
	@Autowired //������ ����sqlsession
	SqlSession sqlSession;
	
	//xml���� resultType�� parameterType�� �ִ��� Ȯ��
	public void setMember(MemberVO mvo) {
		sqlSession.insert("member.setMember", mvo);
	}
	
	public List<MemberVO> getMemberList(String searchOpt, String words) {
    //�˻��� ���� �迭 Map		
		Map<String, String> map = new HashMap<String, String>();
		map.put("searchOpt", searchOpt);
		map.put("words", words);
		
		//
		return sqlSession.selectList("member.getMemberList", map); //void�� �ƴϸ� ������ return
	}
	
	//��������
	public int getMemberCount(String searchOpt, String words) {
	    //�˻��� ���� �迭 Map		
			Map<String, String> map = new HashMap<String, String>();
			map.put("searchOpt", searchOpt);
			map.put("words", words);
			
			
			return sqlSession.selectOne("member.getMemberCount", map); 
		}
	
	
	public void memConfirm(MemberVO mvo) {
		sqlSession.update("member.setMemConfirm", mvo);
	}
	
	public int checkID(String checkID) {
		return sqlSession.selectOne("member.checkID", checkID);
	}
	
	public MemberVO checkLogin(MemberVO mvo) {
		return sqlSession.selectOne("member.checkLogin", mvo);
	}
	
	
}





