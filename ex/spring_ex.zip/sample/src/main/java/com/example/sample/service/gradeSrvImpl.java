package com.example.sample.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.sample.model.gradeVO;
import com.example.sample.repository.gradeDao;

@Service
public class gradeSrvImpl implements gradeSrv {

	@Autowired
	gradeDao gradedao;

	@Override
	public List<gradeVO> getGradeList() {
		
		return gradedao.getGradeList();
	}
	
	
}
