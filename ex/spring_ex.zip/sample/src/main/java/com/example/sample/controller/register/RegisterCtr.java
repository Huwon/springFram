package com.example.sample.controller.register;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.sample.model.gradeVO;
import com.example.sample.service.gradeSrv;

@Controller
public class RegisterCtr {
	
	@Autowired
	gradeSrv gradesrv;

	@RequestMapping("/register/grp_register")
	public String getRegister() {
		return "register/grp_register";
	}
	
	@RequestMapping("/register/grp_grade")
	@ResponseBody
	public List<gradeVO> getGrade() {
		
		return gradesrv.getGradeList();
	}
}
