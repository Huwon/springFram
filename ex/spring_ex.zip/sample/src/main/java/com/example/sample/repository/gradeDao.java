package com.example.sample.repository;

import java.util.List;

import com.example.sample.model.gradeVO;

public interface gradeDao {

	public List<gradeVO> getGradeList();
}
