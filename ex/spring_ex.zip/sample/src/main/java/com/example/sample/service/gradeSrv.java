package com.example.sample.service;

import java.util.List;

import com.example.sample.model.gradeVO;

public interface gradeSrv {
	public List<gradeVO> getGradeList();
	

}
