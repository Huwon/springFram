package com.example.grp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.grp.model.gradeVO;
import com.example.grp.repository.gradeDao;

@Service
public class gradeSrv {

	@Autowired
	gradeDao gradedao;
	
	public List<gradeVO> getgradeList() {
		return gradedao.getgradeList();
	}
}
