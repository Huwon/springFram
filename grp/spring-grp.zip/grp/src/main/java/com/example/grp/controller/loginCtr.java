package com.example.grp.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class loginCtr {
	
	@RequestMapping("/grp_login")
	public String getLogin() {
		return "login/grp_login";
	}
}
