package com.example.grp.service;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.grp.model.EmpVO;
import com.example.grp.repository.EmpDao;

//dao�� ó���ؼ�controller�� ����
@Service
public class EmpSrv {

	@Autowired
	EmpDao empDao;
	
	public void setEmployeeOne(EmpVO evo) {
		empDao.setEmployeeOne(evo);
	}
	
	public EmpVO loginCheck(EmpVO evo, HttpSession session) {
		//���ǻ���-��׶��� ����
		EmpVO vo = empDao.loginCheck(evo);
		if(vo!= null) {
			session.setAttribute("team", vo.getTeam());
			session.setAttribute("userid", vo.getUserid());
			session.setAttribute("username", vo.getUsername());
			session.setAttribute("level", vo.getLevel());
			
		}
		//���ǻ���
		return vo;
	}
	
}
