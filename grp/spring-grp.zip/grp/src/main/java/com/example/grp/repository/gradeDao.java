package com.example.grp.repository;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.grp.model.gradeVO;


@Repository
public class gradeDao {

	@Autowired
	SqlSession sqlSession;
	
	public List<gradeVO> getgradeList() {
		return sqlSession.selectList("grade.getgradeList");
	}
}

