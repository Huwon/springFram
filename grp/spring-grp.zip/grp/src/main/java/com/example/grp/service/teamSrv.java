package com.example.grp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.grp.model.teamVO;
import com.example.grp.repository.teamDao;

@Service
public class teamSrv {

	@Autowired
	teamDao teamdao;
	
	public List<teamVO> getTeamList() {
		return teamdao.getTeamList();
	}
}
