package com.example.grp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.grp.model.EmpVO;
import com.example.grp.model.gradeVO;
import com.example.grp.model.teamVO;
import com.example.grp.service.EmpSrv;
import com.example.grp.service.gradeSrv;
import com.example.grp.service.teamSrv;

@Controller
public class registerCtr {
	
	@Autowired
	teamSrv teamsrv;
	
	@Autowired
	gradeSrv gradesrv;
	
	@Autowired
	EmpSrv empSrv;

	//Ŭ���� �ؼ� ȸ�������� ���δٸ� �� ȭ���� ���̰�-GET
	@RequestMapping(value ="/grp_register", method = RequestMethod.GET)
	public String getRegister() {
		return "register/grp_register";
	}
	
	//�Է°� ����-POST
	@RequestMapping(value ="/grp_register", method = RequestMethod.POST)
	@ResponseBody
	public String setRegister(@ModelAttribute EmpVO evo) {
		empSrv.setEmployeeOne(evo);
		return "success";
	}
	
	@RequestMapping("/getTeamList")
	@ResponseBody //ajax
	public List<teamVO> getTeamList() {
		List<teamVO> list = teamsrv.getTeamList();
		return list;
	}
	
	@RequestMapping("/getgradeList")
	@ResponseBody //ajax
	public List<gradeVO> getgradeList() {
		List<gradeVO> list = gradesrv.getgradeList();
		return list;
	}
}
