package com.example.member;


public class MybatisConnector {

}
