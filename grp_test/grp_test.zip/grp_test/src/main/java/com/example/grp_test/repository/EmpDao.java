package com.example.grp_test.repository;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.grp_test.model.EmpVO;


@Repository
public class EmpDao {

	@Autowired
	SqlSession sqlSession;
	
	public void setEmployeeOne(EmpVO evo) { //EmpVo evo �� �Ķ����(�Ű�����)
		sqlSession.insert("employee.setEmployeeOne", evo);
	}
}
