package com.example.grp_test.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.grp_test.model.GradeVO;
import com.example.grp_test.repository.GradeDao;


@Service
public class GradeSrv {
	@Autowired
	GradeDao gradedao;
	
	public List<GradeVO> getgradeList() {
		return gradedao.getgradeList();
	}
}
