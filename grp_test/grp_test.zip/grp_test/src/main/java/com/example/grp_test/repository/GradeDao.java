package com.example.grp_test.repository;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.grp_test.model.GradeVO;


@Repository
public class GradeDao {
	@Autowired
	SqlSession sqlSession;
	
	public List<GradeVO> getgradeList() {
		return sqlSession.selectList("grade.getgradeList");
	}
}
