package com.example.grp_test.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.grp_test.model.EmpVO;
import com.example.grp_test.repository.EmpDao;


@Service
public class EmpSrv {
	@Autowired
	EmpDao empDao;
	
	public void setEmployeeOne(EmpVO evo) {
		empDao.setEmployeeOne(evo);
	}
}
